package com.emergentes.controlador;

import com.emergentes.dao.DaoProd;
import com.emergentes.dao.DaoProdImpl;
import com.emergentes.modelo.Producto;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "InicioServlet", urlPatterns = {"/InicioServlet"})
public class InicioServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // gestionar el dao y operaciones CRUD
        try {
            //crear variable dao
            DaoProd dao = new DaoProdImpl ();
            
            // para recibir el ID
            int id;
            
            // para getionar registros 
            Producto pro = new Producto ();
            
            // averigu cual es la peticion que nos estan haciendo
            String action = (request.getParameter("action") != null) ? request.getParameter("action") : "view";
            switch(action){
                case "add":
                    // nuevo registro
                    request.setAttribute("produc", pro);
                    request.getRequestDispatcher("frmprod.jsp").forward(request, response);
                    break;
               
                case "edit":
                    //paara editar registro
                    id =  Integer.parseInt(request.getParameter("id"));// convertir en cadena
                    pro = dao.getById(id);
                    request.setAttribute("produc", pro);
                    // transferimos el control 
                    request.getRequestDispatcher("frmprod.jsp").forward(request, response);
                    break;
                
                case "delete":
                // para eliminar registro
                    id =  Integer.parseInt(request.getParameter("id"));
                    dao.delete(id);
                    // redirecciona el control al servlet
                    request.getRequestDispatcher("InicioServlet").forward(request, response);
                    break;
                
                default :
                    // lista de registro
                    List<Producto> lis = dao.getAll();
                    //enviar a vista 
                    request.setAttribute("product", lis);
                    request.getRequestDispatcher("listado.jsp").forward(request, response);
                    break;
                    
            }
        } catch (Exception e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        DaoProd dao = new DaoProdImpl ();
        
        int id =  Integer.parseInt(request.getParameter("id"));
        String descripcion = request.getParameter("descripcion");
        int stock = Integer.parseInt(request.getParameter("stock"));
        
         
        Producto pro =  new Producto();
        
        pro.setId(id);
        pro.setDescripcion(descripcion);
        pro.setStock(stock);
        
        // actualizar
        if (id == 0){
            // nuevo reistro
            try {
                dao.update(pro);
                response.sendRedirect("InicioServlet");
                
            } catch (Exception e) {
                System.out.println("Error "+e.getMessage());
            }
            
        } 
        else{
            // actualizacion de un registro
             try {
                dao.insert(pro);
                response.sendRedirect("InicioServlet");
                
            } catch (Exception e) {
                System.out.println("Error "+e.getMessage());
            }
        }
    }

}
