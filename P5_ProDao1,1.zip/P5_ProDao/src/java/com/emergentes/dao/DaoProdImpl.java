package com.emergentes.dao;

import com.emergentes.modelo.Producto;
import com.emergentes.utiles.ConexionBD;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DaoProdImpl extends ConexionBD implements DaoProd {

    @Override
    public void insert(Producto product) throws Exception {
        try {
            this.conectar();
            String sql = "INSERT into product (descripcion,stock) values(?,?)";
            PreparedStatement ps = this.conn.prepareStatement(sql);

            ps.setString(1, product.getDescripcion());
            ps.setInt(2, product.getStock());
            // ejecutar la consulta

            ps.executeUpdate();

        } catch (Exception e) {
            throw e;
        } finally {
            this.desconectar();
        }
    }

    @Override
    public void update(Producto product) throws Exception {
        try {
            this.conectar();
            String sql = "UPDATE product set descripcion=?, stock=? where id = ?";
            PreparedStatement ps = this.conn.prepareStatement(sql);

            ps.setString(1, product.getDescripcion());
            ps.setInt(2, product.getStock());
            ps.setInt(3, product.getId());

            // ejecutar la consulta
            ps.executeUpdate();

        } catch (Exception e) {
            throw e;
        } finally {
            this.desconectar();
        }
    }

    @Override
    public void delete(int id) throws Exception {
        try {
            this.conectar();
            String sql = "DELETE from product where id = ?";
            PreparedStatement ps = this.conn.prepareStatement(sql);

            ps.setInt(1, id);

            // ejecutar la consulta
            ps.executeUpdate();

        } catch (Exception e) {
            throw e;
        } finally {
            this.desconectar();
        }
    }

    @Override
    public Producto getById(int id) throws Exception {

        Producto pro = new Producto();
        try {
            this.conectar();
            String sql = "select * from product where id = ?";
            PreparedStatement ps = this.conn.prepareStatement(sql);
            ps.setInt(1, id);

            //ejecuta la consulta 
            ResultSet rs = ps.executeQuery();

            // verificar si tiene registro
            if (rs.next()) {
                pro.setId(rs.getInt("id"));
                pro.setDescripcion(rs.getString("descripcion"));
                pro.setStock(rs.getInt("stock"));
            }

        } catch (Exception e) {
            throw e;
        } finally {
            this.desconectar();
        }
        return pro;
    }

    @Override
    public List<Producto> getAll() throws Exception {
        List<Producto> lis = null;
        try {
            this.conectar();
            String sql = "select * from product";
            PreparedStatement ps = this.conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            // inicialixar lista
            lis = new ArrayList<Producto>();
             while(rs.next()){
                 Producto pro = new Producto();
                pro.setId(rs.getInt("id"));
                pro.setDescripcion(rs.getString("descripcion"));
                pro.setStock(rs.getInt("stock"));
                 
                // adicionar a la coleccion
                lis.add(pro);
             }
        } catch (Exception e) {
        } finally {
            this.desconectar();
        }
        return lis;
    }

}
