/*
 * para verrificar si funiona la BD
 */
package com.emergentes.utiles;

public class test {
    public static void main(String[] args) {
        ConexionBD con = new ConexionBD();
        
        con.conectar();
    }
    
}
